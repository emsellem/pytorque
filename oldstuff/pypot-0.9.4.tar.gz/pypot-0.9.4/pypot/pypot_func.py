#!/usr/bin/python

"""
A few useful function to derive the gravitational potential
via pypot
"""

__version__ = '1.0.1 (10-04, 2007)'

## Changes -- 
##   13/04/07- EE - v1.0.1: Addition of stop_program()
##                          

"""
Import of the required modules
"""
import pyfits  # I/O Fits routine
import math    # Standard Libraries
import pylab as p  # Standard Libraries
import numpy as num
import sys
import os 
import scipy 

##################################
###  Test to stop program
##################################
def stop_program() :
   ok = raw_input("Press S to Stop, and any other key to continue...")
   if ok in ["S","s"]  :
      return True
   return False

##################################
###  SECH Function
##################################
def sig_clip(data, nsigma=5.) :
   datamean = num.mean(data, axis=None)
   datasigma = num.std(data, axis=None)
   return data[num.where(data < datamean+ nsigma * datasigma)]

##################################
###  SECH Function
##################################
def sech(z) :
   return 1. / num.cosh(z)

##################################
###  SECH2 Function
##################################
def sech2(z) :
   return (1. / num.cosh(z))**2.

##################################
### Run Example 
##################################
def run_example() :
   file_vobs='rot-7217cd3_both.txt'

##################################
### Reading the Circular Velocity
### Data from file
##################################
def get_vcirc(filename, stepR=1.0):
   #--- Reading data
   radius = Vc = eVc = rfine = Vcfine = 0.
   if not os.path.isfile(filename) :
      print 'OPENING ERROR: File %s not found' %filename
      status = -1
   else :
      f = open(filename, "r")
      lines = f.readlines()
      nlines = len(lines)
      radius = num.zeros(nlines, num.float32)
      Vc = num.zeros_like(radius)
      eVc = num.zeros_like(radius)
      nrad = 0
      for nl in range(nlines) :
         if lines[nl][0] in ["#","!"] or lines[nl] == "\n" :
            continue
         if len(lines[nl].split()) < 8 :
            continue
         if (float(lines[nl].split()[6]) == 0) & (float(lines[nl].split()[7]) == 0):
            radius[nrad] = float(lines[nl].split()[0])
            Vc[nrad] = float(lines[nl].split()[4])
            eVc[nrad] = float(lines[nl].split()[5])
            nrad += 1
      
      radius = radius[:nrad]
      Vc = Vc[:nrad]
      eVc = eVc[:nrad]
 
      #--- Spline interpolation
      rmax = num.max(radius, axis=None)
      rfine = num.arange(0.,rmax,stepR)
      coeff_spline = scipy.interpolate.splrep(radius, Vc, k=1)
      Vcfine = scipy.interpolate.splev(rfine, coeff_spline)
      status = 0
      
   return status, radius, Vc, eVc, rfine, Vcfine

