#!/usr/bin/python

"""
Program for computing the gravitational potential from a combination 
of optical and near-infrared images. 
MPIA / CRAL: @ 2007
Authors: Sebastian Haan
         Eric Emsellem
"""

__version__ = '0.9.4 (14-04, 2007)'

## Changes -- 
##   14/04/07- EE - v0.9.4: Deugging. Correction of deprojection
##                          Change of rotate function
##                          Simplification of some routines
##   13/04/07- EE - v0.9.3: cleaning, redefinition of Width in X,Y
##                          Simplification of some routines
"""
Import of the required modules
"""
import pyfits  # I/O Fits routine
import math    # Standard Libraries
import pylab as p  # Standard Libraries
import numpy as num
import sys
import os 
import scipy 
from numpy import float32
from scipy.fftpack.basic import fft, fft2, fftn, rfft, ifft, ifft2, ifftn, irfft
from scipy.signal.signaltools import convolve, convolve2d, fftconvolve 
from scipy.ndimage.morphology import morphological_gradient
from scipy.ndimage.interpolation import zoom
from scipy import interpolate
from scipy.ndimage.interpolation import rotate  
from scipy.ndimage.interpolation import affine_transform

## Importing all function from the pypot_func module
from pypot_func import *

###########################################################################################################
#-----------------Some Unit Definitions-------------------
##############################################################
##== General units
G = 6.67259e-11     # m^3 *kg^-1 * s^-2
pc = 3.086e16       # m
Msun = 1.99e30      # kg 
unit_GMsun = G * Msun

###########################################################################################################
######### GALAXYMODEL CLASS ##################################
##############################################################
class galaxymodel(object)  :
   def __init__(self, dir=None, inimage=None, gasimage=None, rotfile=None, verbose='off', dist=1., PA=0., Incl=0., cen=(512,512), cengas=(512,512), box=(300,300), boxgas=(300,300), pixelsize=1., pixelsizegas=1., azoom=6, plotlevel=0, debug="off", Nbins=100):

      ##=== Checking if the directory and file name exist.
      ##=== For this we use the os python module
      if verbose == "on" :
         print "Verbose Mode is ON"
         self.verbose = 1
      else :
         self.verbose = 0
      if debug == "on" :
         print "Debug Mode is ON"
         self.debug = 1
      else :
         self.debug = 0

      ##== Plotlevel is allowing some illustrative plots to appear during the
      ##== calculation
      self.plotlevel = plotlevel

      ##=== Some useful number
      self.Dist = dist # Galaxy distance in Mpc
      self.unit_pc = self.Dist * math.pi / 0.648  # Conversion arcsec => pc (pc per arcsec)
      self.PA = PA                                # Position angle in degrees
      self.Incl = Incl                            # Inclination in degrees

      ##== Checking the existence of the two images ===========================================
      if (dir != None) :
         if not os.path.exists(dir):
            print 'ERROR: Path %s' %(dir), ' does not exists, sorry!'
            return
         self.dir = dir + "/"
         if (inimage == None) :
            print 'ERROR: no filename for the main Input Image provided'
            return
         if (gasimage == None) :
            print 'ERROR: no filename for the gas Input Image provided'
            return
         if (rotfile == None) :
            print 'ERROR: no filename for the Rotation Input File provided'
            return

         ##== We now save these information into the class
         if self.verbose :
            print "Trying to open Input files now..."
         self.inimage = inimage
         fullname = self.dir + self.inimage
         self.gasimage = gasimage
         fullname2 = self.dir + self.gasimage
         self.rotfile = rotfile
         self.file_Vcobs = self.dir + self.rotfile
         
         if os.path.isfile(fullname):
            if self.verbose :
               print "Opening the Input image: %s " %(fullname)
            #--------Reading of fits-file for grav. pot----------
            fitsfile = pyfits.open(fullname)
            data = fitsfile[0].data
            #-------------- Fits Header IR Image------------
            listhdr = fitsfile[0].header
            fitsfile.close()

            ##== Checking the step from the Input image (supposed to be in degrees)
            ##== If it doesn't exist, we set the step to 1. (arcsec)
            desc = 'cdelt1'
            if listhdr.has_key(desc) :
               if self.verbose :
                  print 'Read pixel size of Main Image: ', listhdr[desc]
               self.steparc = num.fabs(listhdr[desc] * 3600.) #calculation in arcsec
            else :
               self.steparc = pixelsize # in arcsec
               if self.verbose :
                  print "Didn't find a CDELT descriptor, use step=1" 
         else :
            print 'Filename %s' %(fullname), ' does not exists, sorry!'
            return
            

         if os.path.isfile(fullname2):
            if debug :
               print "Opening the Input image: %s " %(fullname)
            #--------Reading of fits-file for gas distribution----------
            fitsfile2 = pyfits.open(fullname2)
            data_gas = fitsfile2[0].data
            #--- Loading only the first plane
            data_gas = data_gas[0,:,:]
            #-------------- Fits Header Gas Image------------
            listhdr2 = fitsfile2[0].header
            fitsfile2.close()

            ##== Checking the step from the image (supposed to be in degrees)
            ##== If it doesn't exist, we set the step to 1. (arcsec)
            desc = 'cdelt1'
            if listhdr2.has_key(desc) :
               if self.verbose :
                  print 'Read pixel size of Gas Image: ', listhdr2[desc]
               self.steparc2 = num.fabs(listhdr2[desc] * 3600.) #calculation in arcsec
            else :
               self.steparc2 = pixelsizegas # in arcsec
               if self.verbose :
                  print "Didn't find a CDELT descriptor, use step=1" 
         else :
            print 'Filename %s' %(fullname2), ' does not exists, sorry!'
            return
               
         zoomfactor = self.steparc2/self.steparc
         if self.debug :
            print "zoomfactor (pixel size ratio) = %f" %(zoomfactor)

         #---------------Change some galaxy properties here--------------------
         
         self.steppc = self.steparc * self.unit_pc   # Pixel size in pc
         self.steppc2 = self.steparc2 * self.unit_pc # Pixel size of gas image in pc
         self.cen = cen                              # Position for the centre
         self.box = box 
         self.cengas = cengas                            # Position for the centre of gas image
         self.boxgas = boxgas                            # Box coordinates
         self.Nbins = Nbins

         ##== Transfering some numbers for simplicity
         xcen_fits=cen[0]                              # Enter x- and y position of IR image center
         ycen_fits=cen[1]
         xcen_gas=cengas[0]                            # Enter x- and y position of center of gas image
         ycen_gas=cengas[1]
         Xwidth = self.box[0]       # Width of the disk box.  
         Ywidth = self.box[1]
         Xwidth_gas = self.boxgas[0]  # Width of the gas box
         Ywidth_gas = self.boxgas[1]

         ##== Checking if the zoom is larger than 1 before proceeding
         if azoom > 1 :
            self.azoom = azoom
            if self.verbose:
               print "Zoom will be %d" %(self.azoom) 
         else :
            print "ERROR: zoom factor (azoom) should be larger than 1!"
            return

         [Ywidth_z, Xwidth_z] = [Ywidth * self.azoom, Xwidth * self.azoom] ##== Zoomed box size
         ##== Total size will be twice this
         [self.Ytotdisk, self.Xtotdisk] = [Ywidth_z*2, Xwidth_z*2]
         ##== And defining the new center
         [ycen_z, xcen_z] = [Ywidth_z, Xwidth_z]     
         self.disk = num.zeros((self.Ytotdisk, self.Xtotdisk))           ##== Allocating the right space
         self.gasdisk = num.zeros_like(self.disk)
         if self.debug :
            print "DEBUG: new Center = %d, %d - Box size = %d, %d" %(xcen_z, ycen_z, Xwidth_z, Ywidth_z)

         self.Rdiskpx = Xwidth / 2      #Should be changed later eventually
         
         ##== Getting the data within the defined box
         ##== Note that array has length =  2 times Xwidth (resp. Ywidth) and the center at Xwidth (Ywidth)
         ##== We are therefore only filling the inner part of the new array with the original data
         self.disk[ycen_z-Ywidth:ycen_z+Ywidth,xcen_z-Xwidth:xcen_z+Xwidth] = data[ycen_fits-Ywidth:ycen_fits+Ywidth,xcen_fits-Xwidth:xcen_fits+Xwidth] 

         ## Useful (non zero) original part of the data
         self.UsediskX = (xcen_z-Xwidth,xcen_z+Xwidth)
         self.UsediskY = (ycen_z-Ywidth,ycen_z+Ywidth)

         if debug : 
            p.figure(1)
            p.clf()
            p.imshow(data)
            p.title("Original Imaging data")
            p.figure(2)
            p.imshow(self.disk)
            p.title("Transfered data after zooming/box")
            p.draw()
            if stop_program() : sys.exit(0)
            p.close(2)
         
         ## Converting cellsize of GAS array to same cell-size as Input Main Image array#
         data_gas_z = zoom(data_gas, zoomfactor)
         if self.debug :
            p.figure(1)
            p.clf()
            p.imshow(data_gas)
            p.title("Original gas data")
            p.figure(2)
            p.imshow(data_gas_z)
            p.title("Zoomed Gas data")
            p.draw()
            if stop_program() : sys.exit(0)
            p.close(2)
         xcen_zoom = num.round(xcen_gas * zoomfactor)
         ycen_zoom = num.round(ycen_gas * zoomfactor)
         Xwidth_gas_z = num.round(Xwidth_gas * zoomfactor)
         Ywidth_gas_z = num.round(Ywidth_gas * zoomfactor)

         ##== Now taking the right width to extract the gas info
         if self.debug:
            print "Rescaled Gas data had +/- %d, %d pixels" %(Xwidth_gas_z*2, Ywidth_gas_z*2)
            print "To be included in +/- %d, %d pixels" %(Xwidth_z*2, Ywidth_z*2)
         minXwidth = num.minimum(Xwidth_gas_z, Xwidth_z)
         minYwidth = num.minimum(Ywidth_gas_z, Ywidth_z)

         ## Specifying the array for gas distribution
         if self.debug:
            print "Pixel Coordinates for the gas data"
            print ycen_z-minYwidth, ycen_z+minYwidth, xcen_z-minXwidth, xcen_z+minXwidth
            print "Corresponding pixels in new Gas array"
            print ycen_zoom-minYwidth, ycen_zoom+minYwidth, xcen_zoom-minXwidth, xcen_zoom+minXwidth
         self.gasdisk[ycen_z-minYwidth:ycen_z+minYwidth, xcen_z-minXwidth:xcen_z+minXwidth] = data_gas_z[ycen_zoom-minYwidth:ycen_zoom+minYwidth, xcen_zoom-minXwidth:xcen_zoom+minXwidth]
         
         ##Simple Deprojecting of gas disk (including rotation)
         if self.debug :
            gasdisk_save = num.copy(self.gasdisk)
         self.gasdisk = self.deproj(self.gasdisk, self.PA, self.Incl)
         if self.debug :
            p.figure(1)
            p.clf()
            p.imshow(gasdisk_save)
            p.title("Zoomed gas data")
            p.figure(2)
            p.imshow(self.gasdisk)
            p.title("Deprojected Gas data")
            p.draw()
            if stop_program() : sys.exit(0)
            p.close(2)
            
      else :
         print "ERROR: no directory specified \n"
         return

   #============================================================
   #-----Calculation and  Subtraction of Backround--------------
   #============================================================
   def sub_background(self) :
      """ Subtract the background by simply removing the average on one corner
      """
      self.background = num.mean(self.disk[self.UsediskY[0]:self.UsediskY[0]+20,self.UsediskX[0]:self.UsediskX[0]+20], axis=None) 
      if self.verbose :
         print "Background value found to be %lg" %(self.background)
         print "Subtracting this background value... \n"
      self.diskN = self.disk - self.background
      ##-- Replacing all values below 0. with 0.
      self.diskN[num.where(self.diskN < 0.)] = 0.
      
   #============================================================
   #-----Rotation and Deprojecting routine----------------------
   #============================================================
   def deproj(self, disk, pa, incl):
      
      Ysize, Xsize = disk.shape
      if self.debug :
         print "Image to deproject has shape: %f, %f" %(Ysize, Xsize)
      disk_dpj=num.zeros((Ysize+1,Xsize+1))
      disk_rot=num.zeros_like(disk_dpj)
      disk_rec=num.zeros_like(disk_dpj)
      disk_dpj_c=num.zeros((Ysize, Xsize))
      
      #Recentering the disk
      disk_rec[:Ysize,:Xsize] = disk[:,:]
      if self.debug :
         p.figure(1)
         p.clf()
         p.imshow(disk_rec)
         p.title("Transfer of the Image before deprojection")
         p.draw()
         if stop_program() : sys.exit(0)
      
      #Deprojection Matrix
      phi= incl * math.pi / 180.
      dpj_matrix = num.array([[1.0 * math.cos(phi),   0.  ],
                              [0.0, 1.0 ]]) 	
    
      #Rotate Disk around theta
      theta= pa - 90.  ## In degrees
      disk_rot =  scipy.ndimage.interpolation.rotate(num.asarray(disk_rec), theta, reshape=False)
##      disk_rec = num.asarray(disk_rec) 
##      im = scipy.misc.toimage(disk_rec, mode='F')
##      #im = rotate(input=disk,angle=theta,axes=(1,2),reshape=False)
##      im = im.rotate(theta)
##      disk_rot = scipy.misc.fromimage(im) 
##      disk_rot = num.asarray(disk_rot)
    
      #Deproject Image
      offy = Ysize / 2 - 1. - (Ysize / 2 - 1.) * math.cos(phi)
      disk_dpj = affine_transform(disk_rot, dpj_matrix, offset=(offy,0))
      disk_dpj_c[:,:]=disk_dpj[:Ysize,:Xsize]
    
      return disk_dpj_c

   #============================================================
   #--Deprojecting of the disk (includes rotation of the major axis to the north axis)--
   #============================================================
   def deproj_disk(self) :
      """ Deproject the data using the normalised disk intensity, the PA and
          Inclination
      """
      if self.verbose :
         print "Deprojecting the disk ... \n"
      self.diskS = self.deproj(self.diskN, self.PA, self.Incl)
      if self.debug :
         p.figure(1)
         p.clf()
         p.imshow(self.diskS)
         p.title("Deprojected disk")
         p.figure(2)
         p.imshow(self.diskN)
         p.title("Original disk (bulge subtracted)")
         p.draw()
         if stop_program() : sys.exit(0)
         p.close(2)

      ##== Calculate Cartesian coordinates x,y in pc in respect to the center (coord:0,0):
      ##== No central pixel
      xpix, ypix = self.diskS.shape
      xran = num.arange(- xpix / 2.+ 0.5, xpix / 2.+ 0.5, 1.0)
      yran = num.arange(- ypix / 2.+ 0.5, ypix / 2.+ 0.5, 1.0)
      self.xpc, self.ypc = num.meshgrid(xran * self.steppc,yran * self.steppc)
      
      self.rpc = num.sqrt(self.xpc**2 + self.ypc**2)       # cylindrical cordinates: radius r 
      self.theta = num.zeros_like(self.rpc)            # and theta( counting from east axis anticlockwise)
      indtheta = num.where(self.ypc>0)           
      self.theta[indtheta] = num.arccos(self.xpc[indtheta] / self.rpc[indtheta])
      indtheta = num.where(self.ypc<0)
      self.theta[indtheta] = 2.0 * math.pi - num.arccos(self.xpc[indtheta] / self.rpc[indtheta]) 

   #============================================================
   #-----------Create Radial Profile----------------------------
   #============================================================
   def comp_profile(self, r, Data, Nbins):   
      """ Input:
                 input Data array 
                 array with radial coordinate
                 and number of radial bins
          Output: 
                 radial array (1D)
                 Mean intensity array (1D)
      """
      if self.verbose :
         print "Deriving the radial profile ... \n"
      ##== First deriving the max and cutting it in Nbins
      maxr = num.max(r, axis=None)/2
      stepr = maxr / (Nbins-1)
      rsamp = num.arange(0., maxr+stepr, stepr)
      y = num.zeros_like(rsamp)
      ##== Filling in the values for y (only if there are some selected pixels)
      for i in range(len(rsamp)-1):
         sel = num.where((r >= rsamp[i]) & (r < rsamp[i+1]))  ##== selecting an annulus between two bins
         if len(sel) > 0 :
            y[i] = num.mean(Data[sel], axis=None)

      ##-- Returning the obtained profile
      return rsamp, y
      
   #============================================================
   #-----------Create Radial Profile excluding a theta region --
   #============================================================
   def radial_excl(self, r, Data, Nbins):   
      """ Input:
                 input Data array 
                 array with radial coordinate
                 and number of radial bins
                 and theta cut around major axis
          Output: 
                 radial array (1D)
                 Mean intensity array (1D)
      """
      if self.verbose :
         print "Deriving the radial profile for bulge... \n"
      ##== First deriving the max and cutting it in Nbins
      maxr = num.max(r, axis=None) / 2
      stepr = maxr / (Nbins-1)
      rsamp = num.arange(0., maxr+stepr, stepr)
      y = num.zeros_like(rsamp)
      ##== Filling in the values for y (only if there are some selected pixels)
      for i in range(len(rsamp)-1):
         sel = num.where((r >= rsamp[i]) & (r < rsamp[i+1]) & (((self.theta > math.pi*1/6) & (self.theta < math.pi*5/6)) | ((self.theta > math.pi*7/6) & (self.theta < math.pi*11/6))))  ##== selecting an annulus between two bins
         if len(sel) > 0 :
            y[i] = num.mean(Data[sel], axis=None)

      ##== Saving this into the galaxymodel class
      self.rbin_excl = rsamp
      self.rmean_excl = y
      if self.plotlevel > 1 :
         p.clf()
         p.plot(self.rbin_excl,num.log10(self.rmean_excl+1.e-2))
         p.xlabel("R")
         p.ylabel("Radial Profile (in Log10, with Theta cut)")
         p.draw()
         if stop_program() : sys.exit(0)

   #============================================================
   #-----------Bulge component treatment------
   #============================================================
   def bulge_fit(self, disk):
         
      if self.verbose :
         print "Fitting the disk and the bulge... \n"
      Xwidth, Ywidth = self.box[0]*self.steppc, self.box[1]*self.steppc
      x = self.rbin_excl
      ind = num.where(x < Xwidth)
      x = x[ind]
      y_meas = self.rmean_excl[ind]
      I_max = num.max(disk, axis=None)
      Imax_bulge, Rbulge, Imax_disk, Rdisk = I_max*0.5, 0.02*Xwidth, I_max*0.5, 0.4*Xwidth  #Initial values
      #I_bulge = Imax_bulge * pow((1+(x/Rbulge)**2),(-5/2)) #Rgo Plummer Sphere
      I_bulge = Imax_bulge * 4/3 * Rbulge**5 * pow((x**2 + Rbulge**2),(-2)) #projected Plummer Sphere
      I_disk  = Imax_disk * num.exp(-x/Rdisk)  #Model for Disk
      I_disk  = Imax_disk * Rdisk / (2*math.pi) * pow((x**2 + Rdisk**2),(-3/2)) #Kuzmin disk
      y_true = I_bulge + I_disk    #sum of both
              
      def residuals(par, y, x):        # create residual equation: y_true - y_meas
         Imax_bulge, Rbulge, Imax_disk, Rdisk = par
         #err = y - (Imax_bulge * pow((1+(x/Rbulge)**2),(-5/2)) + Imax_disk * num.exp(-x/Rdisk))
         err = y - ( Imax_bulge * Rbulge**5 * 4/3 * pow((x**2 + Rbulge**2),(-2)) + Imax_disk * num.exp(-x/Rdisk) )
         return err
              
      def peval_all(x, par):
         #return par[0] * pow((1+(x/par[1])**2),(-5/2)) + par[2] * num.exp(-x/par[3])
         return par[0] * par[1]**5 * 4/3 * pow((x**2 + (par[1])**2),(-2)) + par[2] * num.exp(-x/par[3])
      
      def peval_bulge(x, par):
         #return par[0] * pow((1+(x/par[1])**2),(-5/2))
         return par[0] *  par[1]**5 * 4/3 * pow((x**2 + (par[1])**2),(-2))
      
      def peval_disk(x, par):
         #return par[2] * num.exp(-x/par[3])
         return par[2] * num.exp(-x/par[3])
              
      par0 = [I_max*0.8, 0.05*Xwidth, I_max*0.2, 0.5*Xwidth]   #Initial conditions
      if self.debug :
         print "Initial conditions for bulge fit : ", par0

      #from scipy.optimize.tnc import fmin_tnc
      from scipy.optimize import leastsq
      self.plsq = leastsq(residuals,par0, args=(y_meas, x),maxfev=10000)
      
      self.bulge = peval_bulge(self.rpc,self.plsq[0])
                              
      if self.plotlevel > 1 :
         p.clf()
         line = p.plot(x,num.log10(y_meas+1.e-2), 'k',x,num.log10(peval_bulge(x,self.plsq[0])+1.e-2),'b', x,num.log10(peval_disk(x,self.plsq[0])+1.e-2), 'r',) #,r_bulge,bulge_mean)
         p.legend(line, ("Total", "Bulge", "Disk"))
         p.xlabel("R [pc]")
         p.ylabel("Flux, Bulge, Disk (log10)")
         p.draw()
         if stop_program() : sys.exit(0)
        
   def bulge_sub(self, disk):
      if self.verbose :
         print "Subtracting the bulge component... \n"
      self.disk_nobulge = disk - self.bulge
        
   def deproj_disk_nobulge(self) :
      if self.verbose :
         print "Deprojecting the disk without bulge... \n"
      self.diskS_nobulge = self.deproj(self.disk_nobulge, self.PA, self.Incl)
        
   def bulge_add(self, disk):
      if self.verbose :
         print "Adding the bulge to the deprojected disk ... \n"
      self.diskF = disk + self.bulge

   #============================================================
   #----------------Calculation of the Kernel Function----------
   #============================================================
   def calc_kernel(self, softparam=0., function="sech2"):                   
      """ Input: radial coordinates, maximal radius of disk
      """
      if self.verbose :
         print "Deriving the kernel ... \n"
      self.softparam = softparam                # Softening Parameter, here set to 0
      self.hzpx = int(self.Rdiskpx / 12.)       # In grid size, the vertical height is taken as 1/12 of the disk radius

      ##== Grid in z from -hz to +hz with no central point
      self.zpx = num.arange(0.5 - self.hzpx, self.hzpx + 0.5, 1.) 
      self.zpc = self.zpx * self.steppc             # Z grid in pc

      if function == "sech" :                        # sech or sech2 function (1/cosh = sech)                           
         self.h = sech(self.zpx / self.hzpx)         # Vertical thickening function in z, has to be normalized later 
      elif function == "sech2" :
         self.h = sech2(self.zpx / self.hzpx)        
      else :
         self.h = sech2(self.zpx / self.hzpx)        

      Sumh = num.sum(self.h, axis=None)         # Integral of h over the entire range
      self.hn = self.h / Sumh                        # Normalised function h

      kernel = self.hn[num.newaxis,num.newaxis,...] / (num.sqrt(self.rpc[...,num.newaxis]**2 + self.softparam**2 + self.zpc**2)) 
      self.kernel = num.sum(kernel, axis=2)
      

   #============================================================
   #----------------Calculation of the potential----------
   #============================================================
   def calc_pot(self):
      #-----------Convolution with mass density by Fourier Transformation-----------------------------
      #Pot = -G * Mass_density *conv* kernel
      
      #Some other modules, but didn't worked so far
      #from scipy.ndimage.filters import convolve  #equal to "_correlate_or_convolve
      #from scipy.fftpack.convolve import convolve, convolve_z, init_convolution_kernel  #fortran objects
      #from numpy import convolve  #only 1-D sequences
      if self.verbose :
              print "Calculating the potential ... \n"
      r = self.rpc
      self.convol = num.zeros((len(r),len(r)))         # Array initialization for grav- potential
      #self.convol = fftconvolve(self.kernel, cmass_r, mode='same')
      self.convol = fftconvolve(self.kernel, self.diskF, mode='same') # Convolution of the kernel with the weight (mass density)
      ##== Saving this into the galaxymodel class
      self.pot = -G * self.convol 

   #============================================================
   #-------- Calculation of Circular Velocity field ------------
   #============================================================
   def calc_vrot_field(self, force):
        
      if self.verbose :
         print "Calculating the rotation velocities from force field... \n"
      return num.sqrt(num.fabs(self.rpc * force))

   #==============================================================
   #-Comparison with observed Rotation Curve and M/L normalization
   #==============================================================
   def scale_Vc(self, file_Vcobs, Vfield, mode):
           
      if self.verbose :
         print "Comparison with observed rotation velocities... \n"
      ##--- Reading of observed rot velocities
      status, Vcobs_r, Vcobs, eVcobs, Vcobs_rint, Vcobs_int = get_vcirc(file_Vcobs)
      ##--- Building a similar profile for the model
      Vmodel_unscaled = num.zeros_like(Vcobs_rint)
      Vfactor_profile = num.zeros_like(Vcobs_rint)
      rpc = self.rpc
      if status != 0 :
         print "Problem reading the input file %s. Assuming M/L of 1." %(file_Vcobs)
         VFactor = num.ones_like(rpc)
      else :
         ##--- Change radial scale from arcsec to pc scale
         Vcobs_rpc = Vcobs_r *  self.unit_pc
         Vcobs_rintpc = Vcobs_rint * self.unit_pc
         maxrpc_obs = num.max(Vcobs_rintpc, axis=None)
         maxVcobs = num.max(Vcobs, axis=None)

         ##--- Rebinning to bin size of calculated velocities / 4
         ##--- Calculation of ratio of observed vel to calculated vel 
         VFactor = num.zeros_like(rpc)

         ## If mode == 1 we proceed with the calculation of a radial M/L
         if mode==1 :
            for i in range(len(Vcobs_rintpc)-1):
               sel = num.where((rpc >= Vcobs_rintpc[i]) & (rpc < Vcobs_rintpc[i+1])) 
               if len(sel) > 0 :
                  ##-- Average of the Vfield within the annulus
                  Vmodel_unscaled[i] = num.mean(Vfield[sel], axis=None)
                  ##-- Ratio of the average observed Vc and the model one for that annulus
                  Vfactor_profile[i] =  (Vcobs_int[i]+Vcobs_int[i+1]) / (2. * Vmodel_unscaled[i])
                  ##-- Saving the value in the Factor profile
                  VFactor[sel] = Vfactor_profile[i]

            ##--- Outside the range of observed circular velocity we keep the
            ##--- average found in the last 1/10th of the range
            VFactor9_10 = VFactor[num.where(Vcobs_rintpc[i] > (9. * maxrpc_obs / 10.))]
            VFactor_out = num.mean(VFactor9_10, axis=None)
            VFactor[num.where(rpc >= maxrpc_obs)] = VFactor_out

         ## If mode != 1 we assume the ratio of the peak values for M/L
         else :
            ##--- Constant Conversion factor
            print 'Constant value assumed for the M/L'
            ##-- Using a sigma clipping to find the real maximum
            maxVobs = num.max(sig_clip(Vcobs_int, 5.), axis=None)
            maxVfield = num.max(sig_clip(Vfield[num.where(rpc < Vcobs_rintpc[-1])], 5.), axis=None)
            ##-- Isolate the 25% highest values and get the mean of that as a scaling measure
            meanVobs = num.mean(Vcobs_int[num.where(Vcobs_int/maxVobs > 6./10.)], axis=None)
            meanVfield = num.mean(Vfield[num.where(Vfield/maxVfield > 6/10.)], axis=None)
            ConstFactor = meanVobs / meanVfield
            VFactor[:,:] = ConstFactor
            Vfactor_profile[:] = ConstFactor
            for i in range(len(Vcobs_rintpc)-1):
               sel = num.where((rpc >= Vcobs_rintpc[i]) & (rpc < Vcobs_rintpc[i+1])) 
               if len(sel) > 0 :
                  ##-- Average of the Vfield within the annulus
                  Vmodel_unscaled[i] = num.mean(Vfield[sel], axis=None)
            
      ##-- Imposing the last value 
      Vmodel_unscaled[-1] = Vmodel_unscaled[-2]

      ##--- M/L is scaled by the square of the V ratio
      self.ML = VFactor**2.0
      
      self.Vmodel_unscaled = Vmodel_unscaled
      self.Vfactor_profile = Vfactor_profile
      if self.plotlevel >= 1 :
         p.clf()
         p.plot(Vcobs_r, Vcobs, 'bo')                        # Create plot of radial profile
         p.errorbar(Vcobs_r, Vcobs, yerr=eVcobs, ecolor='b') # Error bars on observed Vc
         p.plot(Vcobs_rint, Vmodel_unscaled * Vfactor_profile, '--r')  # Overplot of Input Vc
         p.xlabel("R [pc]")
         p.ylabel(r"$V_c$ [km/s]")
         p.ylim(0.,maxVcobs*1.3)
         p.draw()
         if stop_program() : sys.exit(0)
         
   #==============================================================
   #---------------Potential decomposition------------------------
   #==============================================================
   def decompose(self, pot, Nbins, fc_order=8):
        
      if self.verbose :
         print "Decomposition of the potential in Fourier coefficients... \n"        
      r = self.rpc
      theta = self.theta
      maxr = num.max(r, axis=None)/2
      stepr = maxr / (Nbins-1)
      x = num.arange(0., maxr+stepr, stepr)
      y = num.zeros_like(x)
      ##Definition of Fouriercoefficients:
      fc_cos = num.zeros((Nbins, fc_order))
      fc_sin = num.zeros_like(fc_cos)
      fc_cos_n = num.zeros_like(fc_cos)
      fc_sin_n = num.zeros_like(fc_cos)
      #fft_res = num.zeros((len(x),len(x)))
      ##== Filling in the values for y (only if there are some selected pixels)
      for i in range(len(x)-1):
         sel = num.where((r >= x[i]) & (r < x[i+1]))  ##== selecting an annulus between two bins
         if len(sel) > 0 :
            for j in range(fc_order):
               fc_cos[i,j] = num.mean(num.cos(j*theta[sel]) * pot[sel], axis=None)
               fc_sin[i,j] = num.mean(num.sin(j*theta[sel]) * pot[sel], axis=None)
            fc_cos_n[i,:]= fc_cos[i,:]/(num.mean(pot[sel], axis=None)) 
            fc_sin_n[i,:]= fc_sin[i,:]/(num.mean(pot[sel], axis=None)) 
                      
      self.fc_cos = fc_cos
      self.fc_sin = fc_sin
      self.fc_cos_n = fc_cos_n
      self.fc_sin_n = fc_sin_n
                   
        
   #============================================================
   #----------------Calculation of the forces-------------------
   #============================================================
   def calc_force(self, pot):

      if self.verbose :
         print "Calculating the forces ... \n"        
      F_grad = num.gradient(pot) #mass of the probe set to 1
      self.Fx = F_grad[1] / (self.steparc * self.unit_pc)
      self.Fy = F_grad[0] / (self.steparc * self.unit_pc)

      # F_morph_grad = morphological_gradient(pot,size=(10,10)) 

      theta = self.theta 
      #Radial force vector in outward direction
      self.Frad =   self.Fx * num.cos(theta) + self.Fy * num.sin(theta)
      #Tangential force vector in clockwise direction
      self.Ftan = - self.Fx * num.sin(theta) + self.Fy * num.cos(theta)
      
   #============================================================
   #----Calculation of the gravity torques and mass flow rates--
   #============================================================
   def calc_torque(self, r, v, Fx_grad, Fy_grad, Nbins):
           
      if self.verbose :
         print "Calculating the torques... \n"
      self.torque = (self.xpc * Fy_grad - self.ypc * Fx_grad) * self.gasdisk
      ##Average over azimuthal angle and normalization
      maxr = num.max(r, axis=None)/2
      stepr = maxr / (Nbins-1)
      rsamp = num.arange(0., maxr+stepr, stepr)
      t = num.zeros_like(rsamp)
      l = num.zeros_like(rsamp)
      dl = num.zeros_like(rsamp)
      dm = num.zeros_like(rsamp)
      dm_sum = num.zeros_like(rsamp)
      ##== Filling in the values for y (only if there are some selected pixels)
      for i in range(len(rsamp)-1):
         sel = num.where((r >= rsamp[i]) & (r < rsamp[i+1]))  ##== selecting an annulus between two bins
         if len(sel) > 0 :
            ##Torque per unit mass averaged over the azimuth:
            t[i] = num.mean(self.torque[sel], axis=None) / num.mean(self.gasdisk[sel], axis=None)
            ## Angular momentum averaged over the azimuth:
            l[i] = num.mean(r[sel]) * num.mean(v[sel])
            ##Specific angular momentum in one rotation
            dl[i] = t[i] / l[i] * 1.0  
            ##Mass inflow/outflow rate as function of radius( dM/(dR dt) ):
            dm[i] = dl[i] * 2*math.pi * num.mean(r[sel]) * num.mean(self.gasdisk[sel])
            ##Inflow/outflow rates integrated out to a certain radius R
            dm_sum[i] = num.sum(dm[0:i]) * stepr
      self.torque_r = rsamp
      self.torque_mean = t
      self.torque_l = l
      self.torque_dl = dl
      self.torque_dm = dm
      self.torque_dm_sum = dm_sum
