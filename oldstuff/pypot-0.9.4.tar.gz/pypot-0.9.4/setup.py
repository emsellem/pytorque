#!/usr/bin/env python
"""Potpy: gravitational potential of galaxies

Potpy is small set of modules aimed at computing the gravitational potential
and force torques in the equatorial plane given an input FITS images of a galaxy. 
It uses a simple Fourier transform derivation for the potential, with the
optional fit of a bulge component before the deprojection occurs.
"""

import sys

# simple hack to allow use of "python setup.py develop".  Should not affect
# users, only developers.
if 'develop' in sys.argv:
    # use setuptools for develop, but nothing else
    from setuptools import setup
else:
    from distutils.core import setup

import os
if os.path.exists('MANIFEST'): os.remove('MANIFEST')
setup(name='pypot',
      version='0.9.4',
      description='Python Gravitational Potential Module',
      author='Sebastian Haan, Eric Emsellem',
      author_email='haan@mpia-hd.mpg.de',
      maintainer='Sebastian Haan',
      url='http://',
      packages=['pypot'],
#      package_dir={'pypot'},
     )
